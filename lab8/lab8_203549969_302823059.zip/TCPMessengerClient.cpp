#include "TCPMessengerClient.h"
#include "TCPMessengerProtocol.h"
#include "TCPSocket.h"


TCPSocket* messenger;

TCPMessengerClient::TCPMessengerClient(){
	socket = NULL;
	runMainLoop = false;
	sessionAddress = "";
	sessionActive = false;
	connected = false;
}

/**
 * client main loop
 */
void TCPMessengerClient::run(){
	runMainLoop = true;
	while(runMainLoop){
		int command = readCommand();
		switch (command){
			case SEND_MSG_TO_PEER:
			{
				string msg;
				msg = readCommandData();
				cout<<">>"<<msg<<endl;
				break;
			}
			case CLOSE_SESSION_WITH_PEER:
			{
				cout<<"Session was closed by remote peer"<<endl;
				break;
			}
			case OPEN_SESSION_WITH_PEER:
			{
				sessionAddress = readCommandData();
				cout<<"Session was opened by remote peer: "<<sessionAddress<<endl;
				sessionActive = true;
				break;
			}
			case SESSION_ESTABLISHED:{
				cout<<"Session was established"<<endl;
				sessionActive = true;
				break;
			}
			default:
			{
				cout<<"communication with server was interrupted - connection closed"<<endl;
				runMainLoop = false;
				socket->cclose();
				connected = true;
				sessionActive = false;
				sessionAddress = "";
				delete socket;
				break;
			}
		}
	}
}

/**
 * connect to server and start mainLoop 
 */
bool TCPMessengerClient::connect(string ip){
	if(connected) disconnect();
	socket = new TCPSocket(ip,MSNGR_PORT); //port is located in TCPMessengerProtocol
	if (socket == NULL) 
	{
		cout<<"failed to creat socket"<<endl;
		return false;
	}
	connected = true;
	start();
	return true;}

/**
 * return server connection status
 */
bool TCPMessengerClient::isConnected(){
	return connected;
}

/**
 * disconnect from server
 */
bool TCPMessengerClient::disconnect(){
	runMainLoop = false;
	if (socket != NULL){
		if(sessionActive) 
			closeActiveSession();
		socket->cclose();
		this->waitForThread();
	}
	return true;
}

/**
 * open new session with address (ip:port)
 * and close opened session
 */
bool TCPMessengerClient::open(string address){
	if(sessionActive) 
		closeActiveSession();
	cout<<"opening session - "<<address<<endl;
	sendCommand(OPEN_SESSION_WITH_PEER);
	sendCommandData(address);
	return true;
}

/**
 * return session status
 */
bool TCPMessengerClient::isActiveClientSession(){
	return sessionActive;
}

/**
 * close active session
 */
bool TCPMessengerClient::closeActiveSession(){
	sendCommand(CLOSE_SESSION_WITH_PEER);
	sessionActive = false;
	sessionAddress = "";
	return true;
}

/**
 * send message
 */
bool TCPMessengerClient::send(string msg){
	if(!sessionActive) 
		return false;
	sendCommand(SEND_MSG_TO_PEER);
	sendCommandData(msg);
	return true;
}
/**
 * send command
 */
void TCPMessengerClient::sendCommand(int command){
	command = htonl(command);
	socket->send((char*)&command,4);
}

/**
 * send command data
 * in the format: data length (4 byte int) and the data 
 */
void TCPMessengerClient::sendCommandData(string msg){
	int msgLen = msg.length();
	msgLen = htonl(msgLen);
	socket->send((char*)&msgLen,4);
	socket->send(msg.data(),msg.length());
}

/**
 * read incoming command
 */
int TCPMessengerClient::readCommand(){
	int command;
	socket->recv((char*)&command,4);
	command = ntohl(command);
	return command;
}

/**
 * read incoming command data
 */
string TCPMessengerClient::readCommandData(){
	string msg;
	char buff[1500];
	int msgLen;
	socket->recv((char*)&msgLen,4);
	msgLen = ntohl(msgLen);
	int totalrc = 0;
	int rc;
	while (totalrc < msgLen){
		rc = socket->recv((char*)&buff[totalrc],msgLen-totalrc);
		if (rc>0){
			totalrc += rc;
		}else{
			break;
		}
	}
	if (rc > 0 && totalrc == msgLen){
		buff[msgLen] = 0;
		msg = buff;
	}else{
		socket->cclose();
	}
	return msg;
}
