/*
 * main.cpp

 *
 *  Created on: June 20, 2017
 *      Author: user
 */
#ifndef MAIN_CPP_
#define MAIN_CPP_

#include <iostream>
#include <string.h>
#include "TCPMessengerClient.h"

using namespace std;

void showMenu(){
	cout<<"c <server ip> - connect to server"<<endl;
	cout<<"o <peer ip> - open new session"<<endl;
	cout<<"s <message> - send message"<<endl;
	cout<<"cs - close session"<<endl;
	cout<<"d - disconnect from server"<<endl;
	cout<<"x - exit"<<endl;
}

int main(){
	showMenu();
	TCPMessengerClient* messenger = new TCPMessengerClient();
	bool run = true;
	while(run == true){
		string command;
		cin >> command;
			if (command == "c")
			{
				string ip;
				cin >> ip;
				messenger->connect(ip);
				//break;
			}
			else if (command == "o")
			{
				string ip;
				cin >> ip;
				messenger->open(ip);
				//break;
			}
			else if (command == "s")
			{
				string msg;
				getline(std::cin,msg);
				if(msg.size()>0 && msg[0] == ' ')
					msg.erase(0,1);
				if (messenger->isActiveClientSession())
					messenger->send(msg);	
				else
					cout<<"Error: not connected to peer"<<endl;
				//break;
			}
			else if (command == "cs")
			{
				messenger->closeActiveSession();
				//break;
			}
			else if (command == "d")
			{
				messenger->disconnect();
				//break;
			}
			else if (command == "x")
			{
				run = false;
				//break;
			} else {
				cout<<"invalid command"<<endl;
				//break;
			}
	}
	messenger->disconnect();
	delete messenger;
	return 0;
}


#endif /* MAIN_CPP_ */
